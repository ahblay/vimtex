time vim -Nu test.vim
