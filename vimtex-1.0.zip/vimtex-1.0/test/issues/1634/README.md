This test requires that one download an appropriate large project such as the
documentation for PGF/TikZ.
